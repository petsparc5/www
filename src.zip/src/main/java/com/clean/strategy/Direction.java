package com.clean.strategy;

public enum Direction {
	UP, DOWN, LEFT, RIGHT
}
