package com.clean.shipgame;

public enum Status {
    MISS, HIT, SUNK, WIN
}
