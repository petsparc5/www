package com.clean.interfaces;

import com.clean.shipgame.Status;

public interface Torpedo {
	
	public Status fire (int x, int y);

}
